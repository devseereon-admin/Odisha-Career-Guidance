<?php
// Database connection parameters
include "admin/dbconn.php";

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS future_images (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    career VARCHAR(255) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    status ENUM('0', '1') DEFAULT '1',
   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";


if ($conn->query($sql) === TRUE) {
    // echo "Table created successfully";
} else {
    // echo "Error creating table: " . $conn->error;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $career     = htmlspecialchars(strip_tags($_POST["carrer_pur_future"]));
    // print_r($_FILES);
    $image_name = $_FILES["img"]["name"];
    $image_temp = $_FILES["img"]["tmp_name"];
    $target_dir = "draw-your-future-img/";
    $target_file = $target_dir . basename($image_name);

    // Generate a random number between 11111111 and 99999999
    $random_digits = rand(11111111, 99999999);

    // Append random digits to the target file name
    $target_file_with_random = $target_dir . $random_digits . "_" . basename($image_name);

    // Save image to server with random digits in the file name
    if (move_uploaded_file($image_temp, $target_file_with_random)) {
        // Insert data into database
        $sql = "INSERT INTO future_images (id, career, image_path) VALUES ('$random_digits', '$career', '$target_file_with_random')";
        if ($conn->query($sql) === TRUE) {
            
            $page_name = "Draw your future";
            
            $det_sub = mysqli_query($conn, "INSERT INTO career_save_details (career_name, page_from) VALUES ('$career', '$page_name')");
            
            echo "<script>alert('Thank you for your response!');window.location.href='draw-your-future.php';</script>";
        } else {
            echo "<script>alert('Somthing went wrong');window.location.href='draw-your-future.php';</script>";
        }
    } else {
        echo "<script>alert('Error uploading file');window.location.href='draw-your-future.php';</script>";
    }
}

// Close connection
$conn->close();
?>
