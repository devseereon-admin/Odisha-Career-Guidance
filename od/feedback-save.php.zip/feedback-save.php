<?php
// Include database connection file
include 'admin/dbconn.php';

// Check if upload directory exists, if not, create it
$uploadDir = "upload/feedback";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Initialize a message variable
$message = "";

// Check if table exists, and create it if not
$tableName = "feedback";
$tableCheckQuery = "SHOW TABLES LIKE '$tableName'";
$result = $conn->query($tableCheckQuery);

if ($result->num_rows == 0) {
    $createTableQuery = "CREATE TABLE $tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(30) DEFAULT NULL,
        last_name VARCHAR(30) DEFAULT NULL,
        email VARCHAR(30) DEFAULT NULL,
        Phonenumber VARCHAR(30) DEFAULT NULL,
        message TEXT DEFAULT NULL,
        file_name VARCHAR(255) DEFAULT NULL,
        submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    if ($conn->query($createTableQuery) === FALSE) {
        die("Error creating table: " . $conn->error);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $firstName = $conn->real_escape_string($_POST['fname']);
    $lastName = $conn->real_escape_string($_POST['lname']);
    $email = $conn->real_escape_string($_POST['email']);
    $Phonenumber = $conn->real_escape_string($_POST['Phonenumber']);
    $messageText = $conn->real_escape_string($_POST['text']);

    // Handle file upload
    $targetDir = "$uploadDir/";
    $randomFileName = uniqid() . '_' . basename($_FILES["file"]["name"]);
    $targetFile = $targetDir . $randomFileName;
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if file is valid (image or video)
    $allowedImageTypes = ["jpg", "jpeg", "png", "gif"];
    $allowedVideoTypes = ["mp4", "avi", "mov", "wmv"];
    if (in_array($fileType, $allowedImageTypes)) {
        $check = getimagesize($_FILES["file"]["tmp_name"]);
        if ($check === false || $_FILES["file"]["size"] > 5000000) {
            $uploadOk = 0;
        }
    } elseif (in_array($fileType, $allowedVideoTypes)) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $_FILES["file"]["tmp_name"]);
        if (strpos($mime, "video") === false || $_FILES["file"]["size"] > 50000000) {
            $uploadOk = 0;
        }
        finfo_close($finfo);
    } else {
        $uploadOk = 0;
    }

    if ($uploadOk == 1 && move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
        // Insert data into database
        $sql = "INSERT INTO $tableName (first_name, last_name, message, file_name, Phonenumber, email)
                VALUES ('$firstName', '$lastName', '$messageText', '$randomFileName', '$Phonenumber', '$email')";

        if ($conn->query($sql) === TRUE) {
            // Prepare email content
            $to = 'nihar.cts0105@gmail.com'; // Recipient email address
            // $to = 'info.careerguidance2024@gmail.com'; // Recipient email address
            $subject = 'New Feedback Submission';
            $message = "First Name: $firstName\nLast Name: $lastName\nPhone Number: $Phonenumber\nEmail: $email\n\nFeedback:\n$messageText";

            // Headers for attachment
            $boundary = md5(time());
            $headers = "From: $email\r\n";
            $headers .= "Reply-To: $email\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

            // Message body with attachment
            $body = "--$boundary\r\n";
            $body .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
            $body .= "$message\r\n";
            $body .= "--$boundary\r\n";
            $body .= "Content-Type: application/octet-stream; name=\"" . basename($randomFileName) . "\"\r\n";
            $body .= "Content-Disposition: attachment; filename=\"" . basename($randomFileName) . "\"\r\n";
            $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $body .= chunk_split(base64_encode(file_get_contents($targetFile))) . "\r\n";
            $body .= "--$boundary--";

            // Send email
            if (mail($to, $subject, $body, $headers)) {
                $message = "Feedback sent successfully!";
            } else {
                $message = "Failed to send feedback.";
            }
        } else {
            $message = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $message = "Sorry, there was an error uploading your file.";
    }
    $conn->close();

    // Output the message as a JavaScript alert and redirect back to the form
    echo "<script type='text/javascript'>alert('$message'); window.location.href = 'feedback.php';</script>";
}
?>
