<?php
// Include database connection file
include 'admin/dbconn.php';

// Check if upload directory exists, if not, create it
$uploadDir = "upload/my-career-my-identity";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Initialize a message variable
$message = "";

// Check if table exists, and create it if not
$tableName = "my_career_my_identity";
$tableCheckQuery = "SHOW TABLES LIKE '$tableName'";
$result = $conn->query($tableCheckQuery);

if ($result->num_rows == 0) {
    $createTableQuery = "CREATE TABLE $tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(30) NOT NULL,
        last_name VARCHAR(30) NOT NULL,
        email VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    if ($conn->query($createTableQuery) === FALSE) {
        die("Error creating table: " . $conn->error);
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $conn->real_escape_string($_POST['fname']);
    $lastName = $conn->real_escape_string($_POST['lname']);
    $email = $conn->real_escape_string($_POST['email']);
    $messageText = $conn->real_escape_string($_POST['text']);

    // Handle file upload
    $targetDir = "$uploadDir/";
    $randomFileName = uniqid() . '_' . basename($_FILES["file"]["name"]);
    $targetFile = $targetDir . $randomFileName;
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if file is a valid image
    $allowedImageTypes = ["jpg", "jpeg", "png", "gif"];
    if (in_array($fileType, $allowedImageTypes)) {
        $check = getimagesize($_FILES["file"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            $message = "File is not a valid image.";
            $uploadOk = 0;
        }
        // Check image file size
        if ($_FILES["file"]["size"] > 5000000) { // 5MB max size for images
            $message = "Sorry, your image file is too large. Maximum size allowed is 5MB.";
            $uploadOk = 0;
        }
    } else {
        $message = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
            // Insert form data into the database
            $sql = "INSERT INTO $tableName (first_name, last_name, email, message, file_name)
                    VALUES ('$firstName', '$lastName', '$email', '$messageText', '$randomFileName')";

            if ($conn->query($sql) === TRUE) {
                // Prepare email content
                $to = 'info.careerguidance2024@gmail.com'; // Recipient email address
                $subject = 'New message from my career my identity';
                $message = "First Name: $firstName\nLast Name: $lastName\nemail: $email\n\nMessage:\n$messageText";

                // Headers for attachment
                $boundary = md5(time());
                $headers = "From: info@odishacareerguidance.com\r\n"; // Replace with your domain email
                $headers .= "Reply-To: info@odishacareerguidance.com\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

                // Message body with attachment
                $body = "--$boundary\r\n";
                $body .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
                $body .= "$message\r\n";
                $body .= "--$boundary\r\n";
                $body .= "Content-Type: application/octet-stream; name=\"" . basename($randomFileName) . "\"\r\n";
                $body .= "Content-Disposition: attachment; filename=\"" . basename($randomFileName) . "\"\r\n";
                $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
                $body .= chunk_split(base64_encode(file_get_contents($targetFile))) . "\r\n";
                $body .= "--$boundary--";

                // Send email
                if (mail($to, $subject, $body, $headers)) {
                    $message =  "Message sent successfully!";
                } else {
                    $message =  "Failed to send the message.";
                }

                $message =  "Thank You for your Message";
            } else {
                $message =  "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            $message =  "Sorry, there was an error uploading your file.";
        }
    }
    
    
    // Close the connection
    $conn->close();
    
    // Output the message as a JavaScript alert and redirect back to the form
    echo "<script type='text/javascript'>alert('$message'); window.location.href = 'my-career-my-identity.php';</script>";
}

?>
